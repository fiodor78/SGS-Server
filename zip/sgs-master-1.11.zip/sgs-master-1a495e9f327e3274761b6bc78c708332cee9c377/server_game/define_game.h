#define GSERVER		((GServerGame*)global_server)		
#define GSERVER_INIT	GServerGame
#define RSA_BYTES		64
